
#ifndef TIMERS_H
#define	TIMERS_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* TIMERS_H */


// funciones
void inic_Timer3();
void inic_Timer5();
void inic_Timer7();
void inic_Timer9();

void cronometro();
void inic_crono();
void delay_us(unsigned int tiempo);
void delay_ms(unsigned int tiempo);