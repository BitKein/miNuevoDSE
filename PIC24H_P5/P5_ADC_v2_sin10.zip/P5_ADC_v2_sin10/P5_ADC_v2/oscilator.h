

#ifndef OSCILATOR_H
#define	OSCILATOR_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* OSCILATOR_H */



void inic_oscilator ();