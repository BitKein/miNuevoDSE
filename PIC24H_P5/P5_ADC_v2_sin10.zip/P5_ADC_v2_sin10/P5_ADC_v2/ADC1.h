
// Funciones que se llaman desde otros modulos

void inic_ADC1();
void comienzo_muestreo();
void reiniciar_muestreo();
void updateOnLCD_ADC1();

extern int flag_refreshADC;
extern int pagina_LCD;
extern long num_conversiones;
