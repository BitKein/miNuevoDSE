

#ifndef UTILIDADES_H
#define	UTILIDADES_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* UTILIDADES_H */


void conversion_tiempo (unsigned char * dir, unsigned int val);
void conversion_sensores (unsigned char * dir, unsigned long val);